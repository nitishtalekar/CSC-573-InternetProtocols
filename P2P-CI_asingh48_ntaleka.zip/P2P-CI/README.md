# P2P-CI
---
### Nitish Pravin Talekar - ntaleka 
### Aayush Indrapratap Singh - asingh48

1. Run Server on device terminal:
  `python Server.py`
2. Set SERVER for all Clients : 
  In Client.py Line 8,
  Add SERVER IP or SERVER NAME of device on which server is running.
- RFCs: RFC of each client is stored in folder C# as .txt file (RFC_NO.txt).
3. Run Client C1 on device terminal: 
  `python C1.py`
4. Run Client C2 on device terminal:
  `python C2.py`
5. Run multiple requests on basis of Interface of each Client.